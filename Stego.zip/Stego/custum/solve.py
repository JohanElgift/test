import itertools
from hashlib import sha256

charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-=_+"

# Définir la longueur minimale et maximale du mot de passe
min_length = 6
max_length = 7

# Lire l'image chiffrée
encrypted_image = open("custom.jpg", "rb").read()

# Fonction de hashage (remplacez sha256 par l'algorithme réel utilisé)
def hash_password(password):
    return sha256(password.encode()).digest()

# Fonction pour vérifier si le mot de passe est correct
def is_correct_password(password, encrypted_image):
    hashed_password = hash_password(password)
    return xor(encrypted_image, hashed_password) == original_image

# Essayer toutes les combinaisons possibles
for length in range(min_length, max_length + 1):
    for candidate in itertools.product(charset, repeat=length):
        password = "".join(candidate)
        if is_correct_password(password, encrypted_image):
            print(f"Mot de passe trouvé : {password}")
            break

